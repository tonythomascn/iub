#ifndef _COMMON_H_
#define _COMMON_H_

extern bool VERBOSE;
const int BUF_SIZE = 20;
const int MAX_SIZE = 1 << 29;

#endif









